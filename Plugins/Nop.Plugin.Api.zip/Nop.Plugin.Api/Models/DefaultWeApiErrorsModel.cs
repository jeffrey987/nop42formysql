﻿namespace Nop.Plugin.Api.Models
{
    public class DefaultWeApiErrorsModel
    {
        public string Message { get; set; }
        public string MessageDetail { get; set; } 
    }
}